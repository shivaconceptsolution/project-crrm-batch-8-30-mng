from django.contrib import admin
from django.urls import path,include

urlpatterns = [
    path('pm/',include('pmapp.urls')),
    path('admin/', admin.site.urls),
]
