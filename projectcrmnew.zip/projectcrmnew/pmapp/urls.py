from pmapp.views import Hello
from django.urls import path
from . import views

urlpatterns=[
path('',Hello.as_view()),
]