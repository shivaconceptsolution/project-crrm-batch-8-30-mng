from django.shortcuts import render
from django.views import View
from django.http import HttpResponse

# Create your views here.
class Hello(View):
	def get(self,request):
		return render(request,"pmapp/index.html")
	def post(self,request):
		return HttpResponse(request.POST["txtname"])
