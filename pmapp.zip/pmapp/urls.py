from . views import Hello,Swap,StudentCreate
from . siviews import Si
from django.urls import path


urlpatterns=[
path('',Hello.as_view()),
path('swap',Swap.as_view()),
path('si',Si.as_view()),
path('student',StudentCreate.as_view())
]