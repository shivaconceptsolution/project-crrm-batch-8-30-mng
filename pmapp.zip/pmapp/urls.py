from . views import Hello,Swap,StudentCreate,StudentList,StudentDetailView,StudentUpdate,StudentDelete
from . siviews import Si
from django.urls import path
from . import views

urlpatterns=[
path('hello',Hello.as_view()),
path('swap',Swap.as_view()),
path('si',Si.as_view()),
path('',StudentCreate.as_view()),
path('viewstudent',StudentList.as_view()),
path('findstudent/<pk>/',StudentDetailView.as_view()),
path('<pk>/updatestudent',StudentUpdate.as_view()),
path('<pk>/deletestudent',StudentDelete.as_view()),
path('success',views.success,name='success')
]