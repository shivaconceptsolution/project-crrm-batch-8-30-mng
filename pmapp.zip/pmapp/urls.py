from . views import Hello,Swap
from . siviews import Si
from django.urls import path


urlpatterns=[
path('',Hello.as_view()),
path('swap',Swap.as_view()),
path('si',Si.as_view())
]