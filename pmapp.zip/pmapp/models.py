from django.db import models

class StudentsModel(models.Model):
  
    # fields of the model
    rno = models.CharField(max_length = 200)
    sname = models.TextField()
    branch = models.CharField(max_length=10)
    fees = models.IntegerField()
  
    # renames the instances of the model
    # with their title name
    def __str__(self):
        return self.rno + self.sname + self.branch + str(self.fees)