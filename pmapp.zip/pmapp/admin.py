from django.contrib import admin
from .models import StudentsModel
admin.site.register(StudentsModel)

# Register your models here.
