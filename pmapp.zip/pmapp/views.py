from django.shortcuts import render
from django.views import View
from django.http import HttpResponse

# Create your views here.
class Hello(View):
	def get(self,request):
		return render(request,"pmapp/index.html")
	def post(self,request):
		return HttpResponse(request.POST["txtname"])

class Swap(View):
	def get(self,request):
		return render(request,"pmapp/swap.html")
	def post(self,request):
		a,b = request.POST["txtnum2"],request.POST["txtnum1"]
		return render(request,"pmapp/swap.html",{"a":a,"b":b,"res":"a="+a + " b= "+b})	