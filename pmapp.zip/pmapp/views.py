from django.shortcuts import render
from django.views import View
from django.http import HttpResponse
from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from .models import StudentsModel
# Create your views here.

class StudentCreate(CreateView):
	model = StudentsModel
	fields = ['rno','sname','branch','fees']
	success_url = "viewstudent"

class StudentList(ListView):
	model = StudentsModel

class StudentDetailView(DetailView):
   	model = StudentsModel

class StudentUpdate(UpdateView):
	model = StudentsModel
	fields = ['rno','sname','branch','fees']
	success_url = "/pm/viewstudent"

class StudentDelete(DeleteView):
	model = StudentsModel
	success_url = "/pm/viewstudent"
def success(request):
	return HttpResponse("Operation Successfully")

class Hello(View):
	def get(self,request):
		return render(request,"pmapp/index.html")
	def post(self,request):
		return HttpResponse(request.POST["txtname"])

class Swap(View):
	def get(self,request):
		return render(request,"pmapp/swap.html")
	def post(self,request):
		a,b = request.POST["txtnum2"],request.POST["txtnum1"]
		return render(request,"pmapp/swap.html",{"a":a,"b":b,"res":"a="+a + " b= "+b})	