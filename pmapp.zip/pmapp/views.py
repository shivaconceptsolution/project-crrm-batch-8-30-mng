from django.shortcuts import render
from django.views import View
from django.http import HttpResponse
from django.views.generic.edit import CreateView
from .models import StudentsModel
# Create your views here.

class StudentCreate(CreateView):
	model = StudentsModel
	fields = ['rno','sname','branch','fees']

class Hello(View):
	def get(self,request):
		return render(request,"pmapp/index.html")
	def post(self,request):
		return HttpResponse(request.POST["txtname"])

class Swap(View):
	def get(self,request):
		return render(request,"pmapp/swap.html")
	def post(self,request):
		a,b = request.POST["txtnum2"],request.POST["txtnum1"]
		return render(request,"pmapp/swap.html",{"a":a,"b":b,"res":"a="+a + " b= "+b})	